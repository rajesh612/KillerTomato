/* This example does not meet Oracle secure coding standards and modifications may be required to comply with the security practices and standards of your organization.*/
/*
 * Copyright (c) 1999, 2004, Oracle. All rights reserved.  
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * @author Mandar Raje
 */

package checkbox;

public class CheckTest {

    String b[] = new String[]{"1", "2", "3", "4"};


    public String[] getFruit() {
        return b;
    }


    public void setFruit(String[] b) {
        this.b = b;
    }
}
